# Legal Structure and IP Notice

### Lease Structure
- Long-term rooftop lease (10–25 years)
- We retain ownership of panels
- Host receives power + infrastructure + incentives

### IP Protection
- This repo serves as timestamped **prior art**.
- Creative Commons Attribution-NonCommercial 4.0 License applies.

### Community Model
- We are exploring REITs and co-op ownership models for public-benefit deployments

