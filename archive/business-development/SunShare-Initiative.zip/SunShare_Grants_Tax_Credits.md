# Grants & Tax Credit Stack

- **Federal ITC** – 30% credit
- **USDA REAP Grant** – up to 50% cost share (rural)
- **FAA VALE Program** – 75–95% for airport-based solar
- **Texas TERP** – EV + solar combo benefits
- **Local Utility Rebates** – Varies by region

We actively structure each SunShare deployment to maximize grant stacking and investor IRR.

